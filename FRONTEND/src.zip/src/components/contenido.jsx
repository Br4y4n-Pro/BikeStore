import React from "react";
import { Card } from "./card";
import "../assets/styles/contenidoC.css"

export const Contenido = () => {
  return (
    <>
    <div className="ContenidoCard">
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
        </div>
    </>
  );
};
