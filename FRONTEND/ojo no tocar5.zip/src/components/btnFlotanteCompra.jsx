import carr from '../Page/carrito-de-compras (1).png';

export const BotonCompra = () => {
  return (
    <div className="container">
        <div className="logoimg">
        <img src={carr} alt=""></img>
        </div>
      </div>
  )
}
