// import { Footer } from "./components/footer";
// import { Contenido } from "./components/contenido"
// import { Login } from "./components/LOGIN/login";
//import  Naver  from './components'
// import { Registro } from "./components/Registrarse/Registro";
// import { Login } from "./components/LOGIN/login"
import  {Detalles}  from "./components/Detalles/detalles";

function App(){
  return (
    <>
   
      <Detalles/>
      
      {/* <Registro /> */}
    </>
  );
}

export default App;